f = open('admin_id.txt','+w')
f.write('123')
f.close